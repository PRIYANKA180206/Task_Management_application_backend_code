from fastapi import FastAPI
from src.Utils.db import Base,engine
from src.tasks.model import TaskModel
from src.tasks.router import task_router
from src.users.router import user_router

Base.metadata.create_all(engine)

app = FastAPI(title="This is my Task Management Application")
app.include_router(task_router)
app.include_router(user_router)