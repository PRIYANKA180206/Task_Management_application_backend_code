from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker,declarative_base

url='postgresql://postgres:fastapi%4018@localhost:5432/fastapi_db'
engine = create_engine(url)
SessionLocal=sessionmaker(bind=engine)
Base=declarative_base()

def get_db():
    session = SessionLocal()
    try:
        yield session
    finally:
        session.close()