from typing import List
from fastapi import APIRouter,Depends,status
from src.tasks import controller
from src.tasks.dtos import TaskSchema,Taskreponse
from src.Utils.db import get_db
from sqlalchemy.orm import Session
task_router = APIRouter(prefix="/tasks")
@task_router.post("/create",response_model=Taskreponse,status_code=status.HTTP_201_CREATED)
def create_task(body: TaskSchema,db:Session = Depends(get_db)):
    return controller.create_task(body,db)
@task_router.get("/all_tasks",response_model= List[Taskreponse], status_code=status.HTTP_200_OK)
def get_all_tasks(db:Session = Depends(get_db)):
    return controller.get_tasks(db)

@task_router.get("/one_task/{task_id}",response_model=Taskreponse, status_code=status.HTTP_200_OK)
def get_one_task(task_id:int,db:Session=Depends(get_db)):
    return controller.get_one_task(task_id,db)

@task_router.put("/update_task/{task_id}",response_model=Taskreponse, status_code=status.HTTP_201_CREATED)
def update_task(task_id:int,body:TaskSchema,db:Session = Depends(get_db)):
    return controller.update_task(task_id,body,db)

@task_router.delete("/delete_task/{task_id}",response_model=None, status_code=status.HTTP_204_NO_CONTENT)
def delete_task(task_id:int,db:Session=Depends(get_db)):
    return controller.delete_task(task_id,db)