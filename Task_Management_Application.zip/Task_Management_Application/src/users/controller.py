
from sqlalchemy.orm import Session
from src.users.dtos import UserSchema,LoginSchema
from src.users.model import UserModel
from fastapi import HTTPException,status,Request
from pwdlib import PasswordHash
from datetime import datetime,timedelta
import jwt
from jwt.exceptions import InvalidKeyError

SECRET_KEY = "09d25e094faa6ca2556c818166b7a9563b93f7099f6f0f4caa6cf63b88e8d3e7"
ALGORITHM = "HS256"
EXP_TIME_LIMIT = 30

PasswordHash = PasswordHash.recommended()
def get_password_hash(password):
    return PasswordHash.hash(password)
def verify_password(plain_password,hashed_password):
    return PasswordHash.verify(plain_password, hashed_password)

def register(body:UserSchema,db:Session):
    is_user=db.query(UserModel).filter(UserModel.username==body.username).first()
    if is_user:
        raise HTTPException(400,detail="Username already exists...")

    is_user=db.query(UserModel).filter(UserModel.email==body.email).first()
    if is_user:
        raise HTTPException(400,detail="Email already exists...")

    hash_password=get_password_hash(body.password)

    new_user=UserModel(
        name=body.name,
        username=body.username,
        hash_password=hash_password,
        email=body.email

    )
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    return new_user

def login_user(body:LoginSchema,db:Session):
    user=db.query(UserModel).filter(UserModel.username==body.username).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="You Entered Wrong Username")
    if not verify_password(body.password,user.hash_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="Incorrect Password")
    exp_time=datetime.now() + timedelta(seconds=EXP_TIME_LIMIT)
    print(exp_time)
    token=jwt.encode({"_id":user.id,"exp":exp_time.timestamp()},SECRET_KEY,algorithm=ALGORITHM)
    return {"Token" : token}

def is_auth(request:Request,db:Session):
    token = request.headers.get("authorization")
    if not token:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="You are unauthorized")
    token=token.split(" ")[-1]
    data=jwt.decode(token,SECRET_KEY,ALGORITHM)
    user_id=data.get("_id")

    user = db.query(UserModel).filter(UserModel.id == user_id).first()
    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,detail="You are unauthorized")
    return user