from fastapi import APIRouter, Depends,status,Request
from sqlalchemy.orm import Session
from src.Utils.db import get_db
from src.users.dtos import UserSchema,UserResponse,LoginSchema
from src.users import controller

user_router = APIRouter(prefix="/user")

@user_router.post("/register",response_model=UserResponse, status_code=status.HTTP_201_CREATED)
def register(body: UserSchema,db: Session = Depends(get_db)):
    return controller.register(body,db)
@user_router.post("/login",status_code=status.HTTP_200_OK)
def login(body:LoginSchema,db: Session = Depends(get_db)):
    return controller.login_user(body,db)

@user_router.get("/is_auth",status_code=status.HTTP_200_OK,response_model=UserResponse)
def is_auth(request:Request,db: Session = Depends(get_db)):
    return controller.is_auth(request,db)